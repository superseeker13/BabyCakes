
import java.util.ArrayList;
import java.util.List;

public class CartItem{

  protected String Name;
  protected double Price;
  protected double Large;
  protected double Small;
  protected String Size;
  protected List<Toppings> toppings;
  
  public CartItem() {
    Name = " ";
    Price = 0.00;
    toppings = new ArrayList();
  }

  public CartItem(String Name, double P) {
    this.Name = Name;
    this.Price = P;
    toppings = new ArrayList();
  }
  
  public CartItem(String name, double s, double l){
      this.Name = name;
      this.Large = l;
      this.Small = s;
  }
  
  public void setSize(String s){
      this.Size = s;
  }
  public void addTopping(Toppings top){
      this.toppings.add(top);
  }

  public String getName(){
    return this.Name;
  }

  public double getPrice(){
      return this.Price;
  }
  
  public boolean isIn(Toppings test){
      for(Toppings item:toppings){
          if(item.getName().equals(test.getName())){
              return true;
          } 
      }
      return false;
  }
  
  public boolean equals(CartItem objOne){
    if (toString().equals(objOne.toString())){
      if (getPrice() == objOne.getPrice()){
          return true;
      }
    }
    return false;
  }
  
  public double getLarge(){
      return Large;
  }
  
  public double getSmall(){
      return Small;
  }
  
  private int toppingPrice(){
      int sum = 0;
      for(Toppings item:toppings){
          sum += (int)(item.getPrice() * 100);
      }
      return sum;
  }
  public String priceString(){
      String buildString = "" + this.Price;
      for(Toppings item:toppings){
          buildString += "\n" + item.getPrice();
      }
      buildString += "\n\t   " + beverageTotal() + "\n-------------";
      return buildString;
  }
  
  public String nameString(){
      String buildString = this.Name + " (" + this.Size + ")";
      for(Toppings item:toppings){
          buildString += "\n\t" + item.getName();
      }
      
      buildString += "\n     \n--------------------------";
      return buildString;
  }
  public String beverageTotal(){
      int temp = (int)(this.Price * 100);
      temp += toppingPrice();
      return "" + ((double)temp/100.0);
  }
  
  public String output(){
      String buildString = "$" + this.Price + "\t" + this.Name + " (" + this.Size + ")";
      for(Toppings item:toppings){
          buildString += "\n$" + item.getPrice()+ "\t\t" + item.getName();
      }
      buildString += "\n$" + beverageTotal() +"\n\n";
      return buildString;
  }
}