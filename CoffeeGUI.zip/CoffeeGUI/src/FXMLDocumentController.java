import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.AnchorPane;

/**
 *
 * @author Daniel Tomlinson
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private TextField LNField;
    @FXML
    private TextField EMField;
    @FXML
    private TextField FNField;
    @FXML
    private Label FNLabel;
    @FXML
    private Label LNLabel;
    @FXML
    private TextField PTField;
    @FXML
    private Label EMLabel;
    @FXML
    private CheckBox ToffCheck;
    @FXML
    private CheckBox ChocCheck;
    @FXML
    private CheckBox CocCheck;
    @FXML
    private CheckBox AlmCheck;
    @FXML
    private CheckBox VanCheck;
    @FXML
    private CheckBox SFVanCheck;
    @FXML
    private CheckBox HazCheck;
    @FXML
    private CheckBox CarCheck;
    @FXML
    private CheckBox PeppCheck;
    @FXML
    private CheckBox ESCheck;
    @FXML
    private CheckBox SoyCheck;
    @FXML
    private Button EditButton;
    @FXML
    private Button DeleteButton;
    @FXML
    private Button PlaceOrderButton;
    @FXML
    private Button AddButton;
    @FXML
    private ComboBox<String> Combo;
    @FXML
    private RadioButton IcedEspRadio;
    @FXML
    private RadioButton CoffeeRadio;
    @FXML
    private RadioButton FrapRadio;
    @FXML
    private RadioButton EspRadio;
    @FXML
    private Label SaCLabel;
    @FXML
    private Label YourCartLabel;
    @FXML
    private ListView<String> CartItemList;
    @FXML
    private ListView<String> CartPriceList;
    @FXML
    private Label MenuLabel;
    @FXML
    private ListView<String> MenuItemList;
    @FXML
    private ListView<String> MenuPriceList;
    @FXML
    private Label PTLabel;
    @FXML
    private Label CartItemLabel;
    @FXML
    private Label CartQuaLabel;
    @FXML
    private ListView<?> CartQuaList;
    @FXML
    private Label CartPriceLabel;
    @FXML
    private Label MenuItemLabel;
    @FXML
    private RadioButton GrandeRadio;
    @FXML
    private Label SaSLabel;
    @FXML
    private RadioButton VentiRadio;
    @FXML
    private Label MenuPriceLabel;
    @FXML
    private ComboBox<Integer> hours;
    @FXML
    private ComboBox<Integer> minutes;
    
    private List<CartItem> cart;
    private CartItem drink;
    private List<CartItem> drinks;
    private List<Toppings> tops;
    private ObservableList<String> itemNames;
    private ObservableList<String> itemPrices;
    
    @FXML
    private void setDrink(ActionEvent event){
        //drink = new CartItem(Combo.getValue(), )
    }
    
    @FXML
    private void handleAddButtonAction(ActionEvent event) throws IOException {
    // Add Button was clicked, do something…
        TimeAndDate tD = new TimeAndDate();
        double price;
        String errorMsg = null;
        String size = null;
        CartItem menuItem = null;
        for(CartItem item:drinks){
            if(item.getName().equals(Combo.getValue())){
                menuItem = item;
                break;
            }
        }
        
        try{
            if(GrandeRadio.isSelected()){
                price = menuItem.getSmall();
                size = "Grande";
            }else{
                price = menuItem.getLarge();
                size = "Venti";
            }
            
            CartItem temp = new CartItem(Combo.getValue(), price);
            temp.setSize(size);
            
            for(Toppings top:tops){
                temp.addTopping(top);
            }
            cart.add(temp);
        }catch (NullPointerException e){
            errorMsg = "Null Pointer In try-catch line 152, Controller File.";
        }
        
        if(errorMsg != null){
            WriteAndMail(errorMsg);
        }
        
        for(CartItem item:cart){
            System.out.println(item.output());
        }
        
        itemNames  = FXCollections.observableArrayList();
        itemPrices = FXCollections.observableArrayList();
        
        for(CartItem item:cart){
            itemNames.add(item.nameString());
            itemPrices.add(item.priceString());
        }
        itemNames.add("TOTAL");
        itemPrices.add("" + getTotal());
        
        
        CartPriceList.setItems(itemPrices);
        CartItemList.setItems(itemNames);
    }
    
    @FXML
    private void handleEditButtonAction(ActionEvent event) {
    // Edit Button was clicked, do something…
        System.out.println("Edit Button Clicked");
    }
    
    @FXML
   private void handleDeleteButtonAction(ActionEvent event) {
    // Delete Button was clicked, do something…
        String delSelection = CartItemList.getSelectionModel().getSelectedItem();
        for(CartItem item:cart){
            if(item.nameString().equals(delSelection)){
                cart.remove(item);
                break;
            }
        }
        
        itemNames  = FXCollections.observableArrayList();
        itemPrices = FXCollections.observableArrayList();
        for(CartItem item:cart){
            itemNames.add(item.nameString());
            itemPrices.add(item.priceString());
        }
        itemNames.add("TOTAL");
        itemPrices.add("" + getTotal());
        
        CartPriceList.setItems(itemPrices);
        CartItemList.setItems(itemNames);
    }
   
    @FXML
    private void handlePlaceOrderButtonAction(ActionEvent event) throws IOException {
        if(cart.size() > 0){
            WriteAndMail(orderString());
        }else{
            System.out.println("Empty Cart, no order can be placed.");
        }
    }
    
    @FXML
    void toffAction(ActionEvent event) {
        if(ToffCheck.isSelected()){
            tops.add(new Toppings("Toffee Nut", 0.99));
        }
        if(!ToffCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Toffee Nut")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void chocAction(ActionEvent event) {
        if(ChocCheck.isSelected()){
            tops.add(new Toppings("Chocolate Sauce", 0.99));
        }
        if(!ChocCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Chocolate Sauce")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void cocoAction(ActionEvent event) {
        if(CocCheck.isSelected()){
            tops.add(new Toppings("Coconut Milk", 0.99));
        }
        if(!CocCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Cocunut Milk")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void almAction(ActionEvent event) {
        if(AlmCheck.isSelected()){
            tops.add(new Toppings("Almound Milk", 0.99));
        }
        if(!AlmCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Almound Milk")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void vanAction(ActionEvent event) {
        if(VanCheck.isSelected()){
            tops.add(new Toppings("Vanilla", 0.99));
        }
        if(!VanCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Vanilla")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void sfvAction(ActionEvent event) {
        if(SFVanCheck.isSelected()){
            tops.add(new Toppings("Sugar-Free Vanilla", 0.99));
        }
        if(!SFVanCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Sugar-Free Vanilla")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void hazelAction(ActionEvent event) {
        if(HazCheck.isSelected()){
            tops.add(new Toppings("Hazel Nut", 0.99));
        }
        if(!HazCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Hazel Nut")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void carmAction(ActionEvent event) {
        if(CarCheck.isSelected()){
            tops.add(new Toppings("Caramel Sauce", 0.99));
        }
        if(!CarCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Caramel Sauce")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void pepAction(ActionEvent event) {
        if(PeppCheck.isSelected()){
            tops.add(new Toppings("Peppermint", 0.99));
        }
        if(!PeppCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Peppermint")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void espAction(ActionEvent event) {
        if(ESCheck.isSelected()){
            tops.add(new Toppings("Espresso", 1.79));
        }
        if(!ESCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Espresso")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }

    @FXML
    void soyAction(ActionEvent event) {
        if(SoyCheck.isSelected()){
            tops.add(new Toppings("Soy Milk", 0.99));
        }
        if(!SoyCheck.isSelected()){
            for(Toppings item:tops){
                if(item.getName().equals("Soy Milk")){
                    tops.remove(item);
                    System.out.println("Item removed.");
                    break;
                }
            }
        }
    }
    public void WriteAndMail(String msg) throws IOException {
        
        File f = new File("EmailMessage.txt"); 
        if(f.exists() && f.isFile()) {
            f.delete();
        }
        
        File file = new File("EmailMessage.txt");
        try (FileWriter writer = new FileWriter("EmailMessage.txt")) {
            writer.write(msg);
        }
        System.out.println("Sending Message, hopefully.");
        Process p = Runtime.getRuntime().exec("python mail.py");
        System.out.println("Why isn't it working");
    }
    
    private String orderString(){
        String builder = "";
        double value;
        int total = 0;
        for(CartItem item:cart){
            total += (int)(Double.parseDouble(item.beverageTotal()) * 100);
            builder += item.output();
        }
        
        builder += "------------------\nTotal:\t" + (double)total/100.0;
        
        return builder;
    }
    
    private double getTotal(){
        double value;
        int total = 0;
        for(CartItem item:cart){
            total += (int)(Double.parseDouble(item.beverageTotal()) * 100);
        }
        return (double)total/100.0;
    }
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {

    cart = new ArrayList();
    tops = new ArrayList(); 

    EditButton.setDisable(true);
    
    drinks = new ArrayList<CartItem>();
    drinks.add(new CartItem("Coffee", 2.79, 3.69)); drinks.add(new CartItem("Caffe Mistro", 2.79, 3.69));
    drinks.add(new CartItem("Coffee Frappuccino", 4.29, 5.09)); drinks.add(new CartItem("Caramel Frappuccino", 4.99, 5.79));
    drinks.add(new CartItem("Mocha Frappuccino", 4.99, 5.79)); drinks.add(new CartItem("Java Chip Frappuccino", 4.99, 5.79));
    drinks.add(new CartItem("White Chocolate Mocha Frappuccino", 4.99, 5.79)); drinks.add(new CartItem("Caffee Vanilla Frappucino", 4.99, 5.79));
    drinks.add(new CartItem("Vanilla Bean Creme Frappuccino", 4.99, 5.79)); drinks.add(new CartItem("Strawberries & Creme Frappuccino", 4.99, 5.79));
    drinks.add(new CartItem("Double Chocolaty Chip Creme Frappuccino", 4.99, 5.79)); drinks.add(new CartItem("Esspresso", 1.99, 2.49));
    drinks.add(new CartItem("Caffe Latte", 3.89, 4.39)); drinks.add(new CartItem("Cappaccino", 3.89, 4.39));
    drinks.add(new CartItem("Caffe Mocha", 4.69, 5.29)); drinks.add(new CartItem("Vanilla Latte", 4.99, 5.59));
    drinks.add(new CartItem("Caramel Macchiato", 5.39, 5.79)); drinks.add(new CartItem("White Chocolate Mocha", 4.69, 5.29));
    drinks.add(new CartItem("Caffe Americana", 2.79, 3.99)); drinks.add(new CartItem("Iced Caffe Latte", 3.89, 4.39));
    drinks.add(new CartItem("Iced Cappuccino", 3.89, 4.39)); drinks.add(new CartItem("Iced Caffe Mocha", 4.69, 5.29));
    drinks.add(new CartItem("Iced Vanilla Latte", 4.99, 5.59)); drinks.add(new CartItem("Iced Caramel Macchiato", 5.39, 5.79));
    drinks.add(new CartItem("Iced Caffe Latte", 2.59, 2.89));
    
    ObservableList<Integer> hours =FXCollections.observableArrayList(1,2,3,4,5,6,7,8,9,10,11,12);
    hours
    ObservableList<String> items =FXCollections.observableArrayList (
    "[1] Coffee", "[2] Caffe Misto", "[3] Coffee Frappuccino", "[4] Caramel Frappuccino", "[5] Mocha Frappuccino",
    "[6] Java Chip Frappuccino", "[7] White Chocolate Mocha Frappuccino", "[8] Caffe Vanilla Frappucino", "[9] Vanilla Bean Creme Frappuccino", "[10] Strawberries & Creme Frappuccino",
    "[11] Double Chocolaty Chip Creme Frappuccino", "[12] Esspresso", "[13] Caffe Latte", "[14] Cappaccino", "[15] Caffe Mocha",
    "[16] Vanilla Latte", "[17] Caramel Macchiato", "[18] White Chocolate Mocha", "[19] Caffe Americana", "[20] Iced Caffe Latte",
    "[21] Iced Cappuccino", "[22] Iced Caffe Mocha", "[23] Iced Vanilla Latte", "[24] Iced Caramel Macchiato", "[25] Iced Caffe Latte");
    
    ObservableList<String> prices =FXCollections.observableArrayList (
    "[1] 2.79, 3.69", "[2] 2.79, 3.69", "[3] 4.29, 5.09", "[4] 4.99, 5.79", "[5] 4.99, 5.79",
    "[6] 4.99, 5.79", "[7] 4.99, 5.79","[8] 4.99, 5.79", "[9] 4.99, 5.79","[10] 4.99, 5.79",
    "[11] 4.99, 5.79", "[12] 1.99, 2.49", "[13] 3.89, 4.39", "[14] 3.89, 4.39", "[15] 4.69, 5.29",
    "[16] 4.99, 5.59", "[17] 5.39, 5.79", "[18] 4.69, 5.29", "[19] 2.79, 3.99", "[20] 3.89, 4.39",
    "[21] 3.89, 4.39", "[22] 4.69, 5.29", "[23] 4.99, 5.59", "[24] 5.39, 5.79", "[25] 2.59, 2.89");
    
    MenuItemList.setItems(items);
    MenuPriceList.setItems(prices);
    
    ToggleGroup itemGroup = new ToggleGroup();
    ToggleGroup sizeGroup = new ToggleGroup();
    
    CoffeeRadio.setToggleGroup(itemGroup);
    CoffeeRadio.setSelected(true);
      
    FrapRadio.setToggleGroup(itemGroup);
    EspRadio.setToggleGroup(itemGroup);
    IcedEspRadio.setToggleGroup(itemGroup);
    
    VentiRadio.setToggleGroup(sizeGroup);
    VentiRadio.setSelected(true);
      
    GrandeRadio.setToggleGroup(sizeGroup);
    
    ObservableList<String> coffee = FXCollections.observableArrayList("Coffee","Caffe Mistro");
    
    ObservableList<String> frappuccino = FXCollections.observableArrayList(
    "Coffee Frappucino", "Caramel Frappuccino", "Mocha Frappuccino",
    "Java Chip Frappuccino", "White Chocolate Mocha Frappuccino", "Caffe Vanilla Frappuccino", "Vanilla Bean Creme Frappuccino", 
    "Strawberries & Creme Frappuccino", "Double Chocolaty Chip Creme Frappuccino"
    );
    
    ObservableList<String> espresso = FXCollections.observableArrayList(
    "Esspresso", "Caffe Latte", "Cappaccino", "Caffe Mocha",
    "Vanilla Latte", "Caramel Macchiato", "White Chocolate Mocha", "Caffe Americana"
    );
    
    ObservableList<String> iced = FXCollections.observableArrayList(
        "Iced Caffe Latte", "Iced Cappuccino", "Iced Caffe Mocha", 
        "Iced Vanilla Latte", "Iced Caramel Macchiato", "Iced Caffe Latte"
    );
    
    Combo.setItems(coffee);
    
    itemGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>()  
        { 
            public void changed(ObservableValue<? extends Toggle> ob,  
                                                    Toggle o, Toggle n) 
            { 
  
                RadioButton rb = (RadioButton)itemGroup.getSelectedToggle(); 
  
                if (rb != null) { 
                    if(rb == CoffeeRadio){
                         Combo.setItems(coffee);
                    }
                    else if (rb == FrapRadio){
                        Combo.setItems(frappuccino);
                    }
                    else if (rb == EspRadio){
                        Combo.setItems(espresso);
                    }
                    else if (rb == IcedEspRadio){
                        Combo.setItems(iced);
                    } 
                } 
            } 
        }); 
    
    //initialize size to Venti
     
    sizeGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>()  
        { 
            public void changed(ObservableValue<? extends Toggle> ob,  
                                                    Toggle o, Toggle n) 
            { 
  
                RadioButton rb = (RadioButton)sizeGroup.getSelectedToggle(); 
  
                if (rb != null) { 
                    if(rb == VentiRadio){
                         // set size to Venti
                         System.out.println("Size set to Venti");
                    }
                    else if (rb == GrandeRadio){
                        // set size to Grande
                        System.out.println("Size set to Grande");
                    } 
                } 
            } 
        });
    }
}