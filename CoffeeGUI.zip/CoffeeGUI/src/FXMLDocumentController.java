import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;

/**
 *
 * @author Daniel Tomlinson
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private TextField LNField;
    @FXML
    private TextField EMField;
    @FXML
    private TextField FNField;
    @FXML
    private Label FNLabel;
    @FXML
    private Label LNLabel;
    @FXML
    private TextField PTField;
    @FXML
    private Label EMLabel;
    @FXML
    private CheckBox ToffCheck;
    @FXML
    private CheckBox ChocCheck;
    @FXML
    private CheckBox CocCheck;
    @FXML
    private CheckBox AlmCheck;
    @FXML
    private CheckBox VanCheck;
    @FXML
    private CheckBox SFVanCheck;
    @FXML
    private CheckBox HazCheck;
    @FXML
    private CheckBox CarCheck;
    @FXML
    private CheckBox PeppCheck;
    @FXML
    private CheckBox ESCheck;
    @FXML
    private CheckBox SoyCheck;
    @FXML
    private Button EditButton;
    @FXML
    private Button DeleteButton;
    @FXML
    private Button PlaceOrderButton;
    @FXML
    private Button AddButton;
    @FXML
    private ComboBox<String> Combo;
    @FXML
    private RadioButton IcedEspRadio;
    @FXML
    private RadioButton CoffeeRadio;
    @FXML
    private RadioButton FrapRadio;
    @FXML
    private RadioButton EspRadio;
    @FXML
    private Label SaCLabel;
    @FXML
    private Label YourCartLabel;
    @FXML
    private ListView<?> CartItemList;
    @FXML
    private ListView<?> CartPriceList;
    @FXML
    private Label MenuLabel;
    @FXML
    private ListView<String> MenuItemList;
    @FXML
    private ListView<String> MenuPriceList;
    @FXML
    private Label PTLabel;
    @FXML
    private Label CartItemLabel;
    @FXML
    private Label CartQuaLabel;
    @FXML
    private ListView<?> CartQuaList;
    @FXML
    private Label CartPriceLabel;
    @FXML
    private Label MenuItemLabel;
    @FXML
    private RadioButton GrandeRadio;
    @FXML
    private Label SaSLabel;
    @FXML
    private RadioButton VentiRadio;
    @FXML
    private Label MenuPriceLabel;
    
    @FXML
    private void handleAddButtonAction(ActionEvent event) {
    // Add Button was clicked, do something…
    System.out.println("Add Button Clicked");
}
    @FXML
    private void handleEditButtonAction(ActionEvent event) {
    // Edit Button was clicked, do something…
    System.out.println("Edit Button Clicked");
}
    @FXML
   private void handleDeleteButtonAction(ActionEvent event) {
    // Delete Button was clicked, do something…
    System.out.println("Delete Button Clicked");
}
   @FXML
   private void handlePlaceOrderButtonAction(ActionEvent event) {
    // PlaceOrder Button was clicked, do something…
    System.out.println("PlaceOrder Button Clicked");
}
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        
    List<CartItem> ItemList = new ArrayList<>();
    
    ObservableList<String> items =FXCollections.observableArrayList (
    "[1] Coffee", "[2] Caffe Misto", "[3] Coffee Frappucino", "[4] Caramel Frappuccino", "[5] Mocha Frappucino",
    "[6] Java Chip Frappuccino", "[7] White Chocolate Mocha Frappuccino", "[8] Caffe Vanilla Frappucino", "[9] Vanilla Bean Creme Frappuccino", "[10] Strawberries & Creme Frappuccino",
    "[11] Double Chocolaty Chip Creme Frappuccino", "[12] Esspresso", "[13] Caffe Latte", "[14] Cappaccino", "[15] Caffe Mocha",
    "[16] Vanilla Latte", "[17] Caramel Macchiato", "[18] White Chocolate Mocha", "[19] Caffe Americana", "[20] Iced Caffe Latte",
    "[21] Iced Cappuccino", "[22] Iced Caffe Mocha", "[23] Iced Vanilla Latte", "[24] Iced Caramel Macchiato", "[25] Iced Caffe Latte");
    
    ObservableList<String> prices =FXCollections.observableArrayList (
    "[1] 2.79, 3.69", "[2] 2.79, 3.69", "[3] 4.29, 5.09", "[4] 4.99, 5.79", "[5] 4.99, 5.79",
    "[6] 4.99, 5.79", "[7] 4.99, 5.79","[8] 4.99, 5.79", "[9] 4.99, 5.79","[10] 4.99, 5.79",
    "[11] 4.99, 5.79", "[12] 1.99, 2.49", "[13] 3.89, 4.39", "[14] 3.89, 4.39", "[15] 4.69, 5.29",
    "[16] 4.99, 5.59", "[17] 5.39, 5.79", "[18] 4.69, 5.29", "[19] 2.79, 3.99", "[20] 3.89, 4.39",
    "[21] 3.89, 4.39", "[22] 4.69, 5.29", "[23] 4.99, 5.59", "[24] 5.39, 5.79", "[25] 2.59, 2.89");
    
    MenuItemList.setItems(items);
    MenuPriceList.setItems(prices);
    
    ToggleGroup itemGroup = new ToggleGroup();
    ToggleGroup sizeGroup = new ToggleGroup();
    
    CoffeeRadio.setToggleGroup(itemGroup);
    CoffeeRadio.setSelected(true);
      
    FrapRadio.setToggleGroup(itemGroup);
    EspRadio.setToggleGroup(itemGroup);
    IcedEspRadio.setToggleGroup(itemGroup);
    
    VentiRadio.setToggleGroup(sizeGroup);
    VentiRadio.setSelected(true);
      
    GrandeRadio.setToggleGroup(sizeGroup);
    
    ObservableList<String> coffee = FXCollections.observableArrayList("Coffee","Caffe Mistro");
    
    ObservableList<String> frappuccino = FXCollections.observableArrayList(
    "Coffee Frappucino", "Caramel Frappuccino", "Mocha Frappucino",
    "Java Chip Frappuccino", "White Chocolate Mocha Frappuccino", "Caffe Vanilla Frappucino", "Vanilla Bean Creme Frappuccino", 
    "Strawberries & Creme Frappuccino", "Double Chocolaty Chip Creme Frappuccino"
    );
    
    ObservableList<String> espresso = FXCollections.observableArrayList(
    "Esspresso", "Caffe Latte", "Cappaccino", "Caffe Mocha",
    "Vanilla Latte", "Caramel Macchiato", "White Chocolate Mocha", "Caffe Americana"
    );
    
    ObservableList<String> iced = FXCollections.observableArrayList(
        "Iced Caffe Latte", "Iced Cappuccino", "Iced Caffe Mocha", 
        "Iced Vanilla Latte", "Iced Caramel Macchiato", "Iced Caffe Latte"
    );
    
    Combo.setItems(coffee);
    
    itemGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>()  
        { 
            public void changed(ObservableValue<? extends Toggle> ob,  
                                                    Toggle o, Toggle n) 
            { 
  
                RadioButton rb = (RadioButton)itemGroup.getSelectedToggle(); 
  
                if (rb != null) { 
                    if(rb == CoffeeRadio){
                         Combo.setItems(coffee);
                    }
                    else if (rb == FrapRadio){
                        Combo.setItems(frappuccino);
                    }
                    else if (rb == EspRadio){
                        Combo.setItems(espresso);
                    }
                    else if (rb == IcedEspRadio){
                        Combo.setItems(iced);
                    } 
                } 
            } 
        }); 
    
    //initialize size to Venti
     
    sizeGroup.selectedToggleProperty().addListener(new ChangeListener<Toggle>()  
        { 
            public void changed(ObservableValue<? extends Toggle> ob,  
                                                    Toggle o, Toggle n) 
            { 
  
                RadioButton rb = (RadioButton)sizeGroup.getSelectedToggle(); 
  
                if (rb != null) { 
                    if(rb == VentiRadio){
                         // set size to Venti
                         System.out.println("Size set to Venti");
                    }
                    else if (rb == GrandeRadio){
                        // set size to Grande
                        System.out.println("Size set to Grande");
                    } 
                } 
            } 
        });
    
    AddButton.setOnAction(this::handleAddButtonAction);
    
    EditButton.setOnAction(this::handleEditButtonAction);
    
    DeleteButton.setOnAction(this::handleDeleteButtonAction);
    
    PlaceOrderButton.setOnAction(this::handlePlaceOrderButtonAction);
    
    CarCheck.setOnAction((event) -> {
    boolean selected = CarCheck.isSelected();
    System.out.println("Caramel Sauce CheckBox (selected: " + selected + ")");
});
    
    ChocCheck.setOnAction((event) -> {
    boolean selected = ChocCheck.isSelected();
    System.out.println("Chocolate Sauce Checkbox (selected: " + selected + ")");
});
    
    ToffCheck.setOnAction((event) -> {
    boolean selected = ToffCheck.isSelected();
    System.out.println("Toffee Nut Checkbox (selected: " + selected + ")");
});
    
    HazCheck.setOnAction((event) -> {
    boolean selected = HazCheck.isSelected();
    System.out.println("Hazel Nut Checkbox (selected: " + selected + ")");
});
    
    VanCheck.setOnAction((event) -> {
    boolean selected = VanCheck.isSelected();
    System.out.println("Vanilla CheckBox (selected: " + selected + ")");
});
    
    SFVanCheck.setOnAction((event) -> {
    boolean selected = SFVanCheck.isSelected();
    System.out.println("Sugar-Free Vanilla CheckBox (selected: " + selected + ")");
});
    
    PeppCheck.setOnAction((event) -> {
    boolean selected = PeppCheck.isSelected();
    System.out.println("Peppermint CheckBox (selected: " + selected + ")");
});
    
    SoyCheck.setOnAction((event) -> {
    boolean selected = SoyCheck.isSelected();
    System.out.println("Soy Milk CheckBox (selected: " + selected + ")");
});
    
    AlmCheck.setOnAction((event) -> {
    boolean selected = AlmCheck.isSelected();
    System.out.println("Almond Milk CheckBox (selected: " + selected + ")");
});
    
    CocCheck.setOnAction((event) -> {
    boolean selected = CocCheck.isSelected();
    System.out.println("Coconut Milk CheckBox (selected: " + selected + ")");
});
    
    ESCheck.setOnAction((event) -> {
    boolean selected = ESCheck.isSelected();
    System.out.println("Espresso Shot CheckBox (selected: " + selected + ")");
});
    }
}