import smtplib, ssl, sys

port = 465  # For SSL
smtp_server = "smtp.gmail.com"
sender_email = "cs1736cakes@gmail.com"  # Enter your address
receiver_email = "aquaticsnipes@gmail.com"  # Enter receiver address
password = "bilitski"

file = open("EmailMessage.txt", 'r')
message = file.read()
file.close()

file = open("EmailOut.txt", 'w')
file.write(message)
file.close()

context = ssl.create_default_context()
with smtplib.SMTP_SSL(smtp_server, port, context=context) as server:
    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, message)
